#!/usr/bin/python3
import pathlib
import pygubu
from dborders import Session
from models import Labour
from models import ProductionOrden
from models import LabourOrden
from models import OrdenMaterial
from tkinter import messagebox
from pygubuorden_Main import*
from pygubulabour_Main import*
import tkinter as tk
from tkinter import ttk

PROJECT_PATH = pathlib.Path(__file__).parent
PROJECT_UI = PROJECT_PATH / "labourinter.ui"

class LabourinterApp:
    def __init__(self, master=None):
        self.builder = builder = pygubu.Builder()
        builder.add_resource_path(PROJECT_PATH)
        builder.add_from_file(PROJECT_UI)
        # Main widget
        self.mainwindow = builder.get_object("toplevel1", master)
        builder.connect_callbacks(self)
        
        #Entrys
        self.ID = builder.get_object('entryid')
        self.CodeOL = builder.get_object('entrycodeol')     
        self.Codeorden = builder.get_object('entrycodeorden')
        self.Hoursworked = builder.get_object('entryhoursworked')
        
        
        #Datos del material pero para mostrar en tree view
        self.Contribuitornamecolumn = builder.get_object('columncontribuitor')
        self.Employeepositioncolumn = builder.get_object('columnposition')
        self.Salaryratecolumn = builder.get_object('columnsalaryrate')
        self.Hoursworkedcolumn = builder.get_object('columnhoursworked')
        self.Totalcostcolumn = builder.get_object('columntotalcost')
        self.Ordendatecolumn = builder.get_object('columnordendate')
        self.Finishdatecolumn = builder.get_object('columnfinishdate')
        
            
        #tree view
        self.tree = builder.get_object('treeviewlabour')
        columns = ('columncontribuitor', 'columnposition','columnsalaryrate', 'columnhoursworked', 'columnordendate', 'columnfinishdate', 'columntotalcost')

        

        #tupla
        uivars = ('textVar_Id','textVar_Orden','textVar_CodeOL', 'textVar_Hoursworked')  
        
        #le decimos constructor le decimos que trabaje con esas variables
        builder.import_variables(self, uivars)
        

    def run(self):
        self.mainwindow.mainloop()

    def function_include(self):
        session = Session()
    
        for row_id in self.tree.get_children():
            row = self.tree.item(row_id)['values']

            
            labourx = LabourOrden(CodeLO = self.CodeOL.get(),
                                    Codeorden = self.Codeorden.get(),
                                    Hoursworked = self.Hoursworked.get(),
                                    Ordendate = row[4],
                                    Finishdate = row[5],
                                    Totalcost = row[6],
                                    ID = self.ID.get()
                                    )
            session.add(labourx)
            session.commit()
         
        session.close()
        messagebox.showinfo( message='Labour save!!', title='Information') 


    def function_addintree(self):
        session = Session()
        var_id = self.ID.get()
        var_cod = self.Codeorden.get()

        labourx = session.get(Labour, str(var_id))       
        ordenx = session.get(ProductionOrden, str(var_cod))
        
        hoursworkex = float(self.Hoursworked.get())
        totalcost =  hoursworkex * float(labourx.Salaryrate)

        
        if (labourx!=None):
            self.tree.insert("",tk.END,values=(labourx.Contribuitorname, labourx.Employeeposition, labourx.Salaryrate, hoursworkex,  ordenx.Ordendate, ordenx.Finishdate, totalcost))

        else:
            messagebox.showerror(message='could not be included!!', title='Error')      
            
            
            
    def function_search(self):
        session = Session()
        var_id = self.ID.get()

   
        labourx = session.get(Labour, str(var_id))
        if(labourx!=None):       
            messagebox.showinfo( message='Contribuitor found !!', title='Information')
        else:
            messagebox.showerror( message='Contribuitor not found !!', title='Information')


    def function_clean(self):
        self.textVar_Id.set('')
        self.textVar_Orden.set('')
        self.textVar_CodeOL.set('')
        self.textVar_Hoursworked.set('')

    def function_searchorden(self):
        session = Session()
        var_cod = self.Codeorden.get()  

        ordenx = session.get(ProductionOrden, str(var_cod))
        if(ordenx!=None):
            messagebox.showinfo( message='Orden found !!', title='Information')  
        else:
            messagebox.showerror( message='Orden not found !!', title='Information')



if __name__ == "__main__":
    app = LabourinterApp()
    app.run()




