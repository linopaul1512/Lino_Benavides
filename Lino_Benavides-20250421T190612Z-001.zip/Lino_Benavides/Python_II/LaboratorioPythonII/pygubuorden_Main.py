#!/usr/bin/python3
import pathlib
import pygubu
from pygubuclient_Main import *
from pygubuclient_Main import *
from models import ProductionOrden
from models import Client
from dborders import Session
from tkinter import messagebox

PROJECT_PATH = pathlib.Path(__file__).parent
PROJECT_UI = PROJECT_PATH / "ordens.ui"


class OrdensApp:
    def __init__(self, master=None):
        self.builder = builder = pygubu.Builder()
        builder.add_resource_path(PROJECT_PATH)
        builder.add_from_file(PROJECT_UI)
        # Main widget
        self.mainwindow = builder.get_object("toplevel", master)
        builder.connect_callbacks(self)


        self.Codeorden = builder.get_object('entrycode')
        self.ID = builder.get_object('entryid')
        self.Customername = builder.get_object('entryname')
        self.Nameproduct = builder.get_object('entryproduct')
        self.Quantity = builder.get_object('entryquantity')  
        self.Ordedate = builder.get_object('entryordendate')         
        self.Finishdate = builder.get_object('entryfinishdate')
        self.Dateofdelivery = builder.get_object('entrydateofdelivery')
        self.Specifications = builder.get_object('entryspecifications')
      
    
        
        #tupla
        uivars = ('textVar_Code','textVar_Id', 'textVar_Name','textVar_Product', 'textVar_Quantity', 'textVar_Ordendate','textVar_Finishdate', 'textVar_Dateofdelivery','textVar_Specifications')  
        
        #le decimos constructor le decimos que trabaje con esas variables
        builder.import_variables(self, uivars)



    def run(self):
        self.mainwindow.mainloop()

   

    def function_include(self):
        session = Session()
        ordenx = ProductionOrden(Codeorden = self.Codeorden.get(),
                                  ID = self.ID.get(),
                                  Nameproduct = self.Nameproduct.get(),
                                  Quantity = self.Quantity.get(),
                                  Ordendate = self.Ordedate.get(),
                                  Finishdate = self.Finishdate.get(),
                                  Dateofdelivery = self.Dateofdelivery.get(),
                                  Specifications = self.Specifications.get(),
                                  Status = ProductionOrden.States.ACTIVATED)
                            
        
        session.add(ordenx)
        session.commit()
        session.close()
        messagebox.showinfo( message='Orden save!!', title='Information')      

    def function_seacrhorden(self):
        session = Session()
        var_cod = self.Codeorden.get()
        
        
        ordenx = session.get(ProductionOrden, str(var_cod))
        if(ordenx!=None):
            self.textVar_Code.set(ordenx.Codeorden)
            self.textVar_Product.set(ordenx.Nameproduct)
            self.textVar_Quantity.set(ordenx.Quantity)
            self.textVar_Ordendate.set(ordenx.Ordendate) 
            self.textVar_Finishdate.set(ordenx.Finishdate) 
            self.textVar_Dateofdelivery.set(ordenx.Dateofdelivery)
            self.textVar_Specifications.set(ordenx.Specifications)       
            messagebox.showinfo( message='Orden found !!', title='Information')
        else:
            messagebox.showerror( message='Orden not found !!', title='Error')
                   

    def function_modify(self):
        session = Session()
        var_cod = self.Codeorden.get()
       
        ordenx= session.query(ProductionOrden).\
                  filter(ProductionOrden.Codeorden==var_cod).\
                  update({'Nameproduct': self.Nameproduct.get(),
                          'Quantity': self.Quantity.get(), 
                          'Ordendate': self.Ordedate.get(),
                          'Finishdate': self.Finishdate.get(), 
                          'Dateofdelivery': self.Dateofdelivery.get(), 
                          'Specifications': self.Specifications.get()})

        session.commit()
        session.close()
        messagebox.showinfo( message='Client Modify!!', title='Modify')
        self.function_clean()

    def function_delete(self):
        session = Session()
        var_cod = self.Codeorden.get()       
        if(str(ordenx.Status)=='States.ACTIVATED'):
            ordenx= session.query(ProductionOrden).\
                    filter(ProductionOrden.Codeorden==var_cod).\
                    update({'Status': 'INACTIVATED'})
            session.commit()
            session.close()
            messagebox.showinfo( message='Orden Delete!!', title='Delete')
            self.function_clean()
        else:
            resp = messagebox.askquestion('Reactivated Orden','You want to reactivate the orden?')
            ordenx= session.query(ProductionOrden).\
                        filter(ProductionOrden.Codeorden==var_cod).\
                        update({'Status': 'ACTIVATED'})
            session.commit()
            session.close()
            messagebox.showinfo(message='Success reactivating orden', title='Reactivated Orden')
    

    """def function_delete(self):
        session = Session()
        var_cod = self.Codeorden.get()
        ordenx = session.get(ProductionOrden, str(var_cod))
        session.delete(ordenx)
        session.commit()
        session.close()
        messagebox.showinfo( message='Orden delete!!', title='Delete')
        self.function_clean()"""

    def function_searchclient(self):
        session = Session()
        var_id = self.ID.get()
        
        
        clientx = session.get(Client, str(var_id))
        if(clientx!=None):
            self.textVar_Id.set(clientx.ID)
            self.textVar_Name.set(clientx.Customername)      

            messagebox.showinfo( message='Client found !!', title='Information')
        else:
            messagebox.showerror( message='Client not found !!', title='Error')

    def function_clean(self):
        self.textVar_Code.set('')
        self.textVar_Id.set('')
        self.textVar_Name.set('')
        self.textVar_Product.set('')
        self.textVar_Quantity.set('')
        self.textVar_Ordendate.set('')
        self.textVar_Finishdate.set('')
        self.textVar_Dateofdelivery.set('')
        self.textVar_Specifications.set('')


if __name__ == "__main__":
    app = OrdensApp()
    app.run()
