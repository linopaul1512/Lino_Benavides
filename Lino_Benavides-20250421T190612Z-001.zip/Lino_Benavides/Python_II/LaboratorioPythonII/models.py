from dborders import Base
from enum import Enum as Enumerador
from sqlalchemy import Column, Integer, String, Date, Enum, ForeignKey, Float
from sqlalchemy.orm import relationship


class Client(Base):

    class States(Enumerador):
       ACTIVATED = 'A'
       INACTIVATED = 'I'


    __tablename__ = 'client'

    ID = Column(Integer, primary_key = True)
    Customername = Column(String)
    Lastname = Column(String)   
    Adress = Column(String)
    Datebirth = Column(String)
    Phonenumber = Column(String)
    Socialnetwork = Column(String)
    Status = Column(Enum(States))

    clientx = relationship('ProductionOrden', back_populates='ordenx')




class ProductionOrden(Base):

    class States(Enumerador):
       ACTIVATED = 'A'
       INACTIVATED = 'I'


    __tablename__ = 'productionorder'

    Codeorden = Column(String, primary_key = True)
    #Customername = Column(String)
    Nameproduct = Column(String)   
    Quantity = Column(Integer)
    Ordendate = Column(String)
    Finishdate = Column(String)
    Dateofdelivery = Column(String)
    Specifications = Column(String)
    Status = Column(Enum(States))

    ID = Column(Integer, ForeignKey('client.ID'))
    ordenx = relationship('Client', back_populates='clientx')

    ordenx2 = relationship('LabourOrden', back_populates='ordenlaburx')

    ordenx3 = relationship('OrdenMaterial', back_populates='ordenmaterialx')

    ordenx4 = relationship('ServiceOrden', back_populates='codeordenservx')

class LabourOrden(Base):


    __tablename__ = 'labourorden'

    CodeLO = Column(String, primary_key=True)
    Codeorden = Column(String)
    Hoursworked = Column(Integer)
    Ordendate = Column(String)
    Finishdate = Column(String)
    Totalcost = Column(Float)

    ID = Column(String, ForeignKey('labour.ID'))
    ordenlx = relationship('Labour', back_populates='labourx')

    Codeorden = Column(String, ForeignKey('productionorder.Codeorden'))
    ordenlaburx = relationship('ProductionOrden', back_populates='ordenx2')

    def __repr__(self): 
        return f'{Labour.ID}: {self.Totalcost}'


class Labour(Base):

    class States(Enumerador):
        ACTIVATED = 'A'
        INACTIVATED = 'I'
         
    __tablename__ = 'labour'

    ID = Column(String, primary_key = True)
    Contribuitorname = Column(String)  
    Employeeposition = Column(String)  
    Salaryrate = Column(Float)
    Status = Column(Enum(States))

    labourx = relationship('LabourOrden', back_populates='ordenlx')




class RawMaterial(Base):

    class States(Enumerador):
       ACTIVATED = 'A'
       INACTIVATED = 'I'


    __tablename__ = 'rawmaterial'

    Codematerial = Column(String, primary_key = True)
    Description = Column(String)
    Quantityavailable = Column(Integer)
    Unitcost = Column(Float)
    Status = Column(Enum(States))

    rawmaterialx = relationship('OrdenMaterial', back_populates='materialx')




class OrdenMaterial(Base):


    __tablename__ = 'ordenmaterial'
    CodeOM = Column(String, primary_key= True)
    Codematerial = Column(String)
    Codeorden = Column(String)
    Quantity = Column(Integer)
    Totalcost  = Column(Float)

    Codematerial = Column(String, ForeignKey('rawmaterial.Codematerial'))
    materialx = relationship('RawMaterial', back_populates='rawmaterialx')

    Codeorden = Column(String, ForeignKey('productionorder.Codeorden'))
    ordenmaterialx = relationship('ProductionOrden', back_populates='ordenx3')

    def __repr__(self): 
        return f'{RawMaterial.Codematerial}: {self.Totalcost}'

class Roles(Base):

    class States(Enumerador):
       ACTIVATED = 'A'
       INACTIVATED = 'I'


    __tablename__ = 'roles'

    CodeRole = Column(Integer, primary_key = True)
    Description = Column(String)  
    Status = Column(Enum(States))

    user_rel = relationship('User', back_populates='rol_rel')

class User(Base):

    class States(Enumerador):
       ACTIVATED = 'A'
       INACTIVATED = 'I'


    __tablename__ = 'user'

    Codeuser = Column(String, primary_key = True)
    Username = Column(String)
    Passsword = Column(String)   
    Status = Column(Enum(States))

    CodeRole = Column(Integer, ForeignKey('roles.CodeRole'))
    rol_rel = relationship('Roles', back_populates='user_rel')


class Services(Base):

    class States(Enumerador):
       ACTIVATED = 'A'
       INACTIVATED = 'I'


    __tablename__ = 'services'

    Codeserv = Column(String, primary_key = True)
    Description = Column(String)
    Monthlycost = Column(Float) #Costo Mensual
    Status = Column(Enum(States))

    serviceorden_rel = relationship('ServiceOrden', back_populates='servx_rel')



class ServiceOrden(Base):
    
    __tablename__ = 'serviceorden'

    CodeSO = Column(String, primary_key= True)
    
    Codeorden = Column(String, ForeignKey('productionorder.Codeorden'))
    codeordenservx = relationship('ProductionOrden', back_populates='ordenx4')

    Codeserv = Column(String, ForeignKey('services.Codeserv'))
    servx_rel = relationship('Services', back_populates='serviceorden_rel')
    
    #Description = Column(String)

    CIFperorden =Column(Float) 

    def __repr__(self): 
        return f'{self.Codeserv} : {self.CIFperorden}'







     