#!/usr/bin/python3
import pathlib
import pygubu
from models import RawMaterial
from models import ProductionOrden
from pygubuorden_Main import *
from pygubuorden_Main import *
from dborders import Session
from tkinter import messagebox

PROJECT_PATH = pathlib.Path(__file__).parent
PROJECT_UI = PROJECT_PATH / "material.ui"


class MaterialApp:
    def __init__(self, master=None):
        self.builder = builder = pygubu.Builder()
        builder.add_resource_path(PROJECT_PATH)
        builder.add_from_file(PROJECT_UI)
        # Main widget
        self.mainwindow = builder.get_object("toplevel2", master)
        builder.connect_callbacks(self)


        #Datos de material
        self.Codematerial = builder.get_object('entrycode')
        self.Description = builder.get_object('entrydescription')
        self.Quantityavailable = builder.get_object('entryquantity')
        self.Unitcost = builder.get_object('entryunicost')





        #tupla
        uivars = ('textVar_Code', 'textVar_Quantity', 'textVar_Description', 'textVar_Unicost')  
        
        #le decimos constructor le decimos que trabaje con esas variables
        builder.import_variables(self, uivars)


    def run(self):
        self.mainwindow.mainloop()

    def function_include(self):
        session = Session()
        
        
        materialx = RawMaterial(Codematerial = self.Codematerial.get(),
                                  Description = self.Description.get(),
                                  Quantityavailable = self.Quantityavailable.get(),
                                  Unitcost = self.Unitcost.get(),
                                  Status = RawMaterial.States.ACTIVATED)
                

        
        session.add(materialx)
        session.commit()
        session.close()
        messagebox.showinfo( message='Material save!!', title='Information')      

    def function_search(self):
        session = Session()
        var_cod = self.Codematerial.get()
        
        materialx = session.get(RawMaterial, str(var_cod))
        if(materialx!=None):
            self.textVar_Quantity.set(materialx.Quantityavailable)
            self.textVar_Description.set(materialx.Description)
            self.textVar_Unicost.set(materialx.Unitcost)       
            messagebox.showinfo( message='Material found !!', title='Information')     
        else:
            messagebox.showerror( message='Material not found !!', title='Error')     



    def function_modify(self):
        session = Session()
        var_cod = self.Codematerial.get()
       
        materialx= session.query(RawMaterial).\
                  filter(RawMaterial.Codematerial==var_cod).\
                  update({'Description': self.Description.get(),
                          'Quantityavailable': self.Quantityavailable.get(), 
                          'Unitcost': float(self.Unitcost.get())})

        session.commit()
        session.close()
        messagebox.showinfo( message='Client Modify!!', title='Modify')
        self.function_clean()

    def function_delete(self):
        session = Session()
        var_cod = self.Codematerial.get()

        materialx = session.get(RawMaterial,self.Codematerial.get())
        
        if(str(materialx.Status)=='States.ACTIVATED'):
            materialx= session.query(RawMaterial).\
                    filter(RawMaterial.Codematerial==var_cod).\
                    update({'Status': 'INACTIVATED'})
            session.commit()
            session.close()
            messagebox.showinfo( message='Material Delete!!', title='Delete')
            self.function_clean()
        else:
            resp = messagebox.askquestion('Reactivated Material','You want to reactivate the material?')
            materialx= session.query(RawMaterial).\
                        filter(RawMaterial.Codematerial==var_cod).\
                        update({'Status': 'ACTIVATED'})
            session.commit()
            session.close()
            messagebox.showinfo(message='Success reactivating material', title='Reactivated Material')

    def function_clean(self):
        self.textVar_Code.set('')
        self.textVar_Quantity.set('')
        self.textVar_Description.set('')
        self.textVar_Unicost.set('')

        
if __name__ == "__main__":
    app = MaterialApp()
    app.run()