#!/usr/bin/python3
import pathlib
import pygubu
from dborders import Session
from models import *
from pygubuorden_Main import*
from pygubuinterservices_Main import *
from pygubuintermaterial_Main  import *
import tkinter as tk
from tkinter import ttk
PROJECT_PATH = pathlib.Path(__file__).parent
PROJECT_UI = PROJECT_PATH / "calculations.ui"


class CalculationsApp:
    def __init__(self, master=None):
        self.builder = builder = pygubu.Builder()
        builder.add_resource_path(PROJECT_PATH)
        builder.add_from_file(PROJECT_UI)
        # Main widget
        self.mainwindow = builder.get_object("toplevel1", master)
        builder.connect_callbacks(self)

        #Entrys  
        self.Codeorden = builder.get_object('entrycodeorden')
        
        
        
        #Datos del material pero para mostrar en tree view
        self.Elementscolumn = builder.get_object('columnelements')
        self.Costperunitcolumn = builder.get_object('columncostxunit')
        self.Totalcostcolumn = builder.get_object('columntotalcost')
    
        #tree view
        self.tree = builder.get_object('treeviewcalculations')
        columns = ('columnelements', 'columncostxunit', 'columntotalcost')

        #tree view
        self.tree = builder.get_object('treeviewcalculations')
        columns = ('columnelements', 'columncostxunit','columntotalcost')
        

        #tupla
        uivars = ('textVar_Orden')  
        
        #le decimos constructor le decimos que trabaje con esas variables
        builder.import_variables(self, uivars)

    def run(self):
        self.mainwindow.mainloop()

            

    def function_searchorden(self):
        session = Session()
        var_cod = self.Codeorden.get()  

        ordenx = session.get(ProductionOrden, str(var_cod))
        if(ordenx!=None):
            messagebox.showinfo( message='Orden found !!', title='Information')  
        else:
            messagebox.showerror( message='Orden not found !!', title='Information')

    def function_addintree(self):
        session = Session()
        var_mat = OrdenMaterial.Codematerial
        var_cod = self.Codeorden
        var_serv = ServiceOrden.Codeserv
        var_lab = LabourOrden.ID

        """labourx = session.get(LabourOrden, str(var_lab))       
        ordenx = session.get(ProductionOrden, str(var_cod))
        servicex = session.get(ServiceOrden, str(var_serv))
        materialx = session.get(OrdenMaterial,str(var_mat) )"""
      
        labourx=session.query(LabourOrden).filter(LabourOrden.Codeorden==self.Codeorden.get()).all() 
        
        print(labourx) 
        totalcost=0.0 
        for x in labourx: 
            workerx = session.get(Labour, x.ID)
            self.tree.insert("",tk.END,values=(workerx.Employeeposition, x.Totalcost)) 
            totalcost += x.Totalcost 
        self.tree.insert("",tk.END,values=("","",totalcost)) 
         
 
        materialx= session.query(OrdenMaterial).filter(OrdenMaterial.Codeorden==self.Codeorden.get()).all() 
        print(materialx) 
        totalcostmaterial=0.0 
        for x in materialx: 
            rawmaterial = session.get(RawMaterial, x.Codematerial)
            self.tree.insert("",tk.END,values=(rawmaterial.Description, x.Totalcost)) 
            totalcostmaterial += x.Totalcost 
            #print(x.EmployeePosition) 
        self.tree.insert("",tk.END,values=("","",totalcostmaterial)) 
         
 
        servx=session.query(ServiceOrden).filter(ServiceOrden.Codeorden==self.Codeorden.get()) 
        print(servx) 
        totalcostserv=0.0 
        totalcostorden = totalcostmaterial+ totalcostserv + totalcost
        for x in servx: 
            service = session.get(Services, x.Codeserv)
            self.tree.insert("",tk.END,values=(service.Description, x.CIFperorden)) 
            totalcostserv += x.CIFperorden 

        self.tree.insert("",tk.END,values=("","",totalcostserv))   
        self.tree.insert("",tk.END,values=("","",totalcostorden))
            


    def function_clean(self):
        self.textVar_Orden.set('')


if __name__ == "__main__":
    app = CalculationsApp()
    app.run()
