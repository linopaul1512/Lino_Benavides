from dborders import Session
from models import *

def add_user():
    sesion = Session()
    userX = User(
        Codeuser='3333',
        Username = 'Carmelo',
        Passsword = '3333',
        Status = User.States.ACTIVATED,
        CodeRole = '666'        
    )
    sesion.add(userX)
    sesion.commit()
    sesion.close()
add_user()

"""def add_role():
    session = Session()
    role = Roles(
        CodeRole='666',
        Description = 'Operator',
        Status = Roles.States.ACTIVATED
    )
    session.add(role)
    session.commit()
    session.close()
add_role()"""
    