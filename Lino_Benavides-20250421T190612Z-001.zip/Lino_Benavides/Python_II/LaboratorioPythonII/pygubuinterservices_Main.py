#!/usr/bin/python3
import pathlib
import pygubu
import pygubu
from tkinter import messagebox
from dborders import Session
from models import ServiceOrden
from models import Services
from models import ProductionOrden
import tkinter as tk
from tkinter import ttk
PROJECT_PATH = pathlib.Path(__file__).parent
PROJECT_UI = PROJECT_PATH / "interservice.ui"


class InterserviceApp:
    def __init__(self, master=None):
        self.builder = builder = pygubu.Builder()
        builder.add_resource_path(PROJECT_PATH)
        builder.add_from_file(PROJECT_UI)
        # Main widget
        self.mainwindow = builder.get_object("toplevel1", master)
        builder.connect_callbacks(self)


       #Datos del servicio
        self.Codeserv = builder.get_object('entrycodeservice')
        self.Garmentsxmonth = builder.get_object('entrygarmentsxmonth')
        self.CodeSO = builder.get_object('entrycode')
        
    
        #Datos de la orden
        self.Codeorden = builder.get_object('entryorden')

        
        
        #Datos del material pero para mostrar en tree view
        self.Descriptioncolumn = builder.get_object('columnservice')
        self.Monthlycostcolumn = builder.get_object('columnmonthlycost')
        self.Garmentspermonthcolumn = builder.get_object('columngarmentxmonth')
        self.Garmentsperordencolumn = builder.get_object('columngarmentsxorden') 
        self.CIFperordencolumn = builder.get_object('columncifxorden')


        #datos de la orden
        self.Codeorden = builder.get_object('entryorden')
        
        
        #tree view
        self.tree = builder.get_object('treeviewmaterial')
        columns = ('columndescription', 'columnmonthlycost', 'columngarmentxmonth', 'textVar_Garmentsxmonth', 'columncifxorden')
        

        #tupla
        uivars= ('textVar_Orden', 'textVar_Code', 'textVar_Codeserv','textVar_Garmentsxmonth',)

        #le decimos constructor le decimos que trabaje con esas variables
        builder.import_variables(self, uivars)


    def run(self):
        self.mainwindow.mainloop()

    def function_include(self):
        session = Session()
        
        for row_cod in self.tree.get_children():
            row = self.tree.item(row_cod)['values']


            servicex = ServiceOrden(CodeSO = self.CodeSO.get(),
                                    Codeorden = self.Codeorden.get(),
                                    Codeserv = self.Codeserv.get(),
                                    CIFperorden = row[3]
                                    )
            session.add(servicex)
            session.commit()  

        session.close()
        messagebox.showinfo( message='Assigned Service!!', title='Information')




    
    def function_addintree(self):
        session = Session()
        var_cod = self.Codeserv.get()
        var_cod2 = self.Codeorden.get()

        materialx = session.get(Services, str(var_cod))
        ordenx = session.get(ProductionOrden, str(var_cod2))

        garmentsxmonthly = float(self.Garmentsxmonth.get())
        cifgarment = materialx.Monthlycost / garmentsxmonthly 

        ordenx = session.get(ProductionOrden, str(var_cod2))
        ciforden= float(cifgarment) * ordenx.Quantity

        
        if (materialx!=None):
            self.tree.insert("",tk.END,values=(materialx.Description, materialx.Monthlycost, garmentsxmonthly , cifgarment, ordenx.Quantity , ciforden))

        else:
            messagebox.showinfo(message='No se pudo incluir !!', title='Information')      

        
    def function_search(self):
        session = Session()
        var_cod = self.Codeserv.get()


        servicex = session.get(Services, str(var_cod))
        if(servicex != None):
            messagebox.showinfo( message='Service found !!', title='Information')
        else:
            messagebox.showerror( message='Service not found !!', title='Error')


    def function_clean(self):
        self.textVar_Orden.set('')  
        self.textVar_Code.set('')
        self.textVar_Codeserv.set('')
        self.textVar_Garmentsxmonth.set('')



    def function_searchorden(self):
        session = Session()
        var_cod = self.Codeorden.get()  

        ordenx = session.get(ProductionOrden, str(var_cod))
        if(ordenx!=None):
            self.textVar_Orden.set(ordenx.Codeorden)
            messagebox.showinfo( message='Orden found !!', title='Information')
        else:
            messagebox.showerror( message='Orden found !!', title='Error')


if __name__ == "__main__":
    app = InterserviceApp()
    app.run()