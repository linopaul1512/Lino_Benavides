#!/usr/bin/python3
import pathlib
import pygubu
from dborders import Session
from models import Labour
from models import ProductionOrden
from models import LabourOrden
from tkinter import messagebox
from pygubuorden_Main import*
PROJECT_PATH = pathlib.Path(__file__).parent
PROJECT_UI = PROJECT_PATH / "labour.ui"


class LabourApp:
    def __init__(self, master=None):
        self.builder = builder = pygubu.Builder()
        builder.add_resource_path(PROJECT_PATH)
        builder.add_from_file(PROJECT_UI)
        # Main widget
        self.mainwindow = builder.get_object("toplevel1", master)
        builder.connect_callbacks(self)
        
        
        #Datos dela mano de labour
        self.ID = builder.get_object('entryid')
        self.Contribuitorname = builder.get_object('entrycontribuitor')
        self.Employeeposition = builder.get_object('entryemployeeposition')
        self.Salaryrate = builder.get_object('entrysalaryrate')
        


        #tupla
        uivars = ('textVar_Id','textVar_Contribuitor', 'textVar_Employeeposition',  'textVar_Salaryrate')  
        
        #le decimos constructor le decimos que trabaje con esas variables
        builder.import_variables(self, uivars)
        

    def run(self):
        self.mainwindow.mainloop()

    def function_include(self):
        session = Session()
        
       
        """totalcost= int(self.Hoursworked.get()) * float(self.Salaryrate.get())
        self.textVar_Totalcost.set(totalcost)"""
           
        
        
        labourx = Labour(ID = self.ID.get(),
                                  Contribuitorname = self.Contribuitorname.get(),
                                  Employeeposition = self.Employeeposition.get(),
                                  Salaryrate = self.Salaryrate.get(),
                                  Status = Labour.States.ACTIVATED)
                

        
        session.add(labourx)
        session.commit()
        session.close()
        messagebox.showinfo( message='Labour save!!', title='Information')  


    def function_search(self):
        session = Session()
        var_id = self.ID.get()

   
        labourx = session.get(Labour, int(var_id))
        if(labourx!=None):
            self.textVar_Contribuitor.set(labourx.Contribuitorname)
            self.textVar_Employeeposition.set(labourx.Employeeposition)
            self.textVar_Salaryrate.set(labourx.Salaryrate)
            messagebox.showinfo( message='Client found !!', title='Information')
        else:
            messagebox.showerror( message='Client not found !!', title='Error')

    def function_delete(self):
        session = Session()
        var_id = self.ID.get()

        labourx = session.get(Labour,self.ID.get())
        
        if(str(labourx.Status)=='States.ACTIVATED'):
            labourx= session.query(Labour).\
                    filter(Labour.ID==var_id).\
                    update({'Status': 'INACTIVATED'})
            session.commit()
            session.close()
            messagebox.showinfo( message='Labour Delete!!', title='Delete')
            self.function_clean()
        else:
            resp = messagebox.askquestion('Reactivated labour','You want to reactivate the labour?')
            labourx= session.query(Labour).\
                        filter(Labour.ID==var_id).\
                        update({'Status': 'ACTIVATED'})
            session.commit()
            session.close()
            messagebox.showinfo(message='Success reactivating labour', title='Reactivated Labour')


    def function_modify(self):
        session = Session()
        var_id = self.ID.get()
       
        labourx= session.query(Labour).\
                  filter(Labour.ID==var_id).\
                  update({'Contribuitorname': self.Contribuitorname.get(),
                          'Employeeposition': self.Employeeposition.get(), 
                          'Salaryrate': self.Salaryrate.get(),
                          })
                  
        
        session.commit()
        session.close()
        messagebox.showinfo( message='Labour Modify!!', title='Modify')
        self.function_clean()
    
        

    def function_clean(self):
        self.textVar_Id.set('')
        self.textVar_Contribuitor.set('')
        self.textVar_Employeeposition.set('')
        self.textVar_Salaryrate.set('')


if __name__ == "__main__":
    app = LabourApp()
    app.run()
