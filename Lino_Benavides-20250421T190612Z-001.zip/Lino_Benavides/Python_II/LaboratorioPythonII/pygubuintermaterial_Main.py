#!/usr/bin/python3
import pathlib
import pygubu
from dborders import Session
from models import RawMaterial
from models import ProductionOrden
from models import OrdenMaterial
from tkinter import messagebox
from pygubuorden_Main import*
from pygubumaterial_Main import*
import tkinter as tk
from tkinter import ttk

PROJECT_PATH = pathlib.Path(__file__).parent
PROJECT_UI = PROJECT_PATH / "materialinter.ui"


class MaterialinterApp:
    def __init__(self, master=None):
        self.builder = builder = pygubu.Builder()
        builder.add_resource_path(PROJECT_PATH)
        builder.add_from_file(PROJECT_UI)
        self.totalcostz= 0

        # Main widget
        self.mainwindow = builder.get_object("toplevel2", master)
        builder.connect_callbacks(self)

        #Datos de material_orden
        self.Codematerial = builder.get_object('entrycode')
        self.CodeOM = builder.get_object('entrycodeom')
        self.Quantity = builder.get_object('entryquantity')

        #Datos del material pero para mostrar en tree view
        self.Quantitycolumn = builder.get_object('columnquantity')
        self.Unicostcolumn = builder.get_object('columnunicost')
        self.Descriptioncolumn = builder.get_object('columndescription')
        self.Totalcost = builder.get_object('columntotalcost')

        #datos de la orden
        self.Codeorden = builder.get_object('entrycodeorden')
        
        
        #tree view
        self.tree = builder.get_object('treeviewmaterial')
        columns = ('columnquantity', 'columndscription', 'columnunicost', 'columntotalcost')
        #tree = ttk.Treeview(windows, columns=columns, show='headings')

       


        #tupla
        uivars = ('textVar_Orden','textVar_Code', 'textVar_Codeom', 'textVar_Quantity')  
        
        #le decimos constructor le decimos que trabaje con esas variables
        builder.import_variables(self, uivars)       



    def run(self):
        self.mainwindow.mainloop()

    def function_include(self):
        session = Session()
        var_cod = self.Codematerial.get()
        
            

        for row_cod in self.tree.get_children():
            row = self.tree.item(row_cod)['values']

            materialx = OrdenMaterial(CodeOM = self.CodeOM.get(),
                                    Codematerial = self.Codematerial.get(),
                                    Codeorden = self.Codeorden.get(),
                                    Quantity = row[2],
                                    Totalcost = row[3]
                                    )
            session.add(materialx)
            session.commit()
            
        session.close()
        messagebox.showinfo( message='Material save!!', title='Information')   


    def function_addintree(self):
        session = Session()
        var_cod = self.Codematerial.get()
        materialx = session.get(RawMaterial, str(var_cod))
        quantitytext = float(self.Quantity.get())
        totalcost = quantitytext * materialx.Unitcost
        
        if (materialx!=None):
            self.tree.insert("",tk.END,values=(materialx.Description,quantitytext,materialx.Unitcost,totalcost))

        else:
            messagebox.showinfo(message='No se pudo incluir !!', title='Information')      

        


    def function_search(self):
        session = Session()
        var_cod = self.Codematerial.get()
        
        materialx = session.get(RawMaterial, str(var_cod))
        if (materialx!=None):
            messagebox.showinfo( message='Material found !!', title='Information') 

        else:
            messagebox.showerror(message='Material Not found !!', title='Error')

    
    def function_clean(self):
        self.textVar_Orden.set('')
        self.textVar_Code.set('')
        self.textVar_Codeom.set('')
        self.textVar_Quantity.set('')


    def function_searchorden(self):
        session = Session()
        var_cod = self.Codeorden.get()  

        ordenx = session.get(ProductionOrden, str(var_cod))
        if(ordenx!=None):
            self.textVar_Orden.set(ordenx.Codeorden)
            messagebox.showinfo( message='Orden found !!', title='Information') 
        else:
            messagebox.showerror( message='Orden not found !!', title='Error') 
 

if __name__ == "__main__":
    app = MaterialinterApp()
    app.run()
