#!/usr/bin/python3
import pathlib
import pygubu
from dborders import Session
from models import Client
from tkinter import messagebox

PROJECT_PATH = pathlib.Path(__file__).parent
PROJECT_UI = PROJECT_PATH / "client.ui"


class ClientApp:
    def __init__(self, master=None):
        self.builder = builder = pygubu.Builder()
        builder.add_resource_path(PROJECT_PATH)
        builder.add_from_file(PROJECT_UI)
        # Main widget
        self.mainwindow = builder.get_object("toplevel1", master)
        builder.connect_callbacks(self)

        self.ID = builder.get_object('entryid')
        self.Customername = builder.get_object('entryname')
        self.Lastname = builder.get_object('entrylastname')
        self.Adress = builder.get_object('entryadress')
        self.Datebirth = builder.get_object('entrydatebirth')
        self.Phonenumber = builder.get_object('entryphonenumber')
        self.Socialnetwork = builder.get_object('entrysocialnetwork')


        #tupla
        uivars = ('textVar_ID', 'textVar_Name','textVar_Lastname', 'textVar_Adress', 'textVar_Datebirth','textVar_Phonenumber', 'textVar_Socialnetwork')
        #le decimos constructor le decimos que trabaje con esas variables
        builder.import_variables(self, uivars)
        

    def run(self):
        self.mainwindow.mainloop()

    def function_include(self):
        session = Session()
       
        client = Client(ID = int(self.ID.get()),
                        Customername= self.Customername.get(),
                        Lastname = self.Lastname.get(),
                        Adress  = self.Adress.get(),
                        Datebirth = self.Datebirth.get(),
                        Phonenumber = self.Phonenumber.get(),
                        Socialnetwork = self.Socialnetwork.get(),
                        Status = Client.States.ACTIVATED)
        
        session.add(client)
        session.commit()
        session.close()
        messagebox.showinfo( message='Client save!!', title='Information')       



    def function_clean(self):
        self.textVar_ID.set('')
        self.textVar_Name.set('')
        self.textVar_Lastname.set('')
        self.textVar_Adress.set('')
        self.textVar_Datebirth.set('')
        self.textVar_Phonenumber.set('')       
        self.textVar_Socialnetwork.set('')  

        
        
        
    def function_modify(self):
        session = Session()
        var_id = self.ID.get()
       
        clientx= session.query(Client).\
                  filter(Client.ID==var_id).\
                  update({'Customername': self.Customername.get(),
                          'Lastname': self.Lastname.get(), 
                          'Adress': self.Adress.get(),
                          'Datebirth': self.Datebirth.get(), 
                          'Phonenumber': self.Phonenumber.get(), 
                          'Socialnetwork': self.Socialnetwork.get()})
                  
        
        session.commit()
        session.close()
        messagebox.showinfo( message='Client Modify!!', title='Modify')
        self.function_clean()
    
    
    def function_search(self):
        session = Session()
        var_id = self.ID.get()

        
        clientx = session.get(Client, int(var_id))
        if(clientx!=None):
            self.textVar_ID.set(clientx.ID)
            self.textVar_Name.set(clientx.Customername)
            self.textVar_Lastname.set(clientx.Lastname)
            self.textVar_Adress.set(clientx.Adress)
            self.textVar_Datebirth.set(clientx.Datebirth) 
            self.textVar_Phonenumber.set(clientx.Phonenumber) 
            self.textVar_Socialnetwork.set(clientx.Socialnetwork)       
            messagebox.showinfo( message='Client found !!', title='Information')
        else:
            messagebox.showerror( message='Client not fond !!', title='Error')

    def function_delete(self):
        session = Session()
        var_id = self.ID.get()

        clientX = session.get(Client,self.ID.get())
        
        if(str(clientX.Status)=='States.ACTIVATED'):
            clientx= session.query(Client).\
                    filter(Client.ID==var_id).\
                    update({'Status': 'INACTIVATED'})
            session.commit()
            session.close()
            messagebox.showinfo( message='Client Delete!!', title='Delete')
            self.function_clean()
        else:
            resp = messagebox.askquestion('Reactivated client','You want to reactivate the client?')
            clientx= session.query(Client).\
                        filter(Client.ID==var_id).\
                        update({'Status': 'ACTIVATED'})
            session.commit()
            session.close()
            messagebox.showinfo(message='Success reactivating client', title='Reactivated Client')

if __name__ == "__main__":
    app = ClientApp()
    app.run()
