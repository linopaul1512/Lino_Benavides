#!/usr/bin/python3
import pathlib
import pygubu
from tkinter import messagebox
from dborders import Session
from models import ServiceOrden
from models import Services
from models import ProductionOrden
#import pygu
PROJECT_PATH = pathlib.Path(__file__).parent
PROJECT_UI = PROJECT_PATH / "services.ui"


class ServicesApp:
    def __init__(self, master=None):
        self.builder = builder = pygubu.Builder()
        builder.add_resource_path(PROJECT_PATH)
        builder.add_from_file(PROJECT_UI)
        # Main widget
        self.mainwindow = builder.get_object("toplevel1", master)
        builder.connect_callbacks(self)
    
        
        #Datos del servicio
        self.Codeserv = builder.get_object('entrycode')
        self.Description = builder.get_object('entrydescription')
        self.Monthlycost = builder.get_object('entrymonthlycost')

        #tupla
        uivars= ('textVar_Code','textVar_Description','textVar_Monthlycost')

        #le decimos constructor le decimos que trabaje con esas variables
        builder.import_variables(self, uivars)

    def run(self):
        self.mainwindow.mainloop()

    def function_include(self):
        session = Session()
        
  
        servicex = Services(Codeserv = self.Codeserv.get(),
                                  Description = self.Description.get(),
                                  Monthlycost = self.Monthlycost.get(),
                                  Status = Services.States.ACTIVATED)
                

       
    
        session.add(servicex)
        session.commit()
        session.close()
        messagebox.showinfo( message='Assigned Service!!', title='Information')

    def function_search(self):
        session = Session()
        var_cod = self.Codeserv.get()

   
        servicex = session.get(Services, str(var_cod))
        if(servicex!=None):
            self.textVar_Description.set(servicex.Description)
            self.textVar_Monthlycost.set(servicex.Monthlycost)       
            messagebox.showinfo( message='Service found !!', title='Information')
        else:
            messagebox.showinfo( message='Orden not found !!', title='Information')


    def function_clean(self):     
        self.textVar_Code.set('')
        self.textVar_Description.set('')
        self.textVar_Monthlycost.set('')
   

    def function_delete(self):
        session = Session()
        var_cod = self.Codeserv.get()

        servicex = session.get(Services,self.Codeserv.get())
        
        if(str(servicex.Status)=='States.ACTIVATED'):
            servicex= session.query(Services).\
                    filter(Services.Codeserv==var_cod).\
                    update({'Status': 'INACTIVATED'})
            session.commit()
            session.close()
            messagebox.showinfo( message='Service Delete!!', title='Delete')
            self.function_clean()
        else:
            resp = messagebox.askquestion('Reactivated Service','You want to reactivate the service?')
            servicex= session.query(Services).\
                        filter(Services.Codeserv==var_cod).\
                        update({'Status': 'ACTIVATED'})
            session.commit()
            session.close()
            messagebox.showinfo(message='Success reactivating service', title='Reactivated Service')




    def function_modify(self):
        session = Session()
        var_cod = self.Codeserv.get()
       
        servicex= session.query(Services).\
                  filter(Services.Codeserv==var_cod).\
                  update({'Description': self.Description.get(),
                          'Monthlycost': self.Monthlycost.get()})

        session.commit()
        session.close()
        messagebox.showinfo( message='Service Modify!!', title='Modify')
        self.function_clean()


if __name__ == "__main__":
    app = ServicesApp()
    app.run()
