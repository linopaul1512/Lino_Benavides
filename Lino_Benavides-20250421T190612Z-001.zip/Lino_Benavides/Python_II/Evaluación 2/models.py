from dbproduct import Base
from enum import Enum as Enumerador
from sqlalchemy import Column, Integer, String, Date, Enum, ForeignKey, Float
from sqlalchemy.orm import relationship


class Product(Base):

    __tablename__ = 'product'

    codigo = Column(Integer, primary_key = True)
    name = Column(String)
    price = Column(Float)
    stock = Column(String)


    product_supplier = relationship('Product_Supplier', back_populates = 'product')


class Product_Supplier(Base):

    __tablename__ = 'product_supplier'

    cod = Column(Integer, primary_key = True)
    rut = Column(Integer)


    codigo_product = Column(Integer, ForeignKey('product.codigo'))
    rut_supplier = relationship('Supplier', back_populates = 'product')


class Category(Base):

    __tablename__ = 'category'

    ID = Column(Integer, primary_key = True)
    name = Column(String)
    description = Column(String)


    codigo = relationship('Product', back_populates = 'product')

class Supplier(Base):

    __tablename__ = 'supplier'

    rut = Column(Integer, primary_key = True)
    name = Column(String)
    telefono = Column(String)
    direction = Column(String)
    web = Column(String)


    product_supplier  = relationship('Product_Supplier', back_populates = 'product')
    desarrolladores = relationship('Desarrollador', back_populates = 'proyecto')


