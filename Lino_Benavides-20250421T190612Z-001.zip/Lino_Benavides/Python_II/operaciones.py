from datetime import datetime
from db import Session
from models import *

def agregar_especialidad():
    sesion = Session()
    especialidadJr = Especialidad(
        nombre = 'Desarrrollador Jr',
        salario_base = 14,
        estado = Especialidad.Estados.ACTIVO
    )
    sesion.add(especialidadJr)
    especialidadSr = Especialidad(
        nombre = 'Desarrrollador Sr',
        salario_base = 17,
        estado = Especialidad.Estados.ACTIVO
    )
    especialidadAnalista = Especialidad(
        nombre = 'Analista de Sistemas',
        salario_base = 12,
        estado = Especialidad.Estados.ACTIVO
    )
    especialidades = [especialidadSr, especialidadAnalista]
    sesion.add_all(especialidades)
    #sesion.commit()
    sesion.close()

def agregar_desarrollador():
    sesion = Session()
    dev = Desarrollador(
        cedula = '123456',
        nombre_apellido = 'Juanito Alimaña',
        fecha_ingreso = datetime.now(),
        area = Desarrollador.Areas.MANTENIMIENTO,
        estado = Desarrollador.Estados.ACTIVO,
        especialidad = Especialidad(
            nombre = 'Especialista en Mantenimiento',
            salario_base = 33,
            estado = Especialidad.Estados.ACTIVO
        )
    )
    #sesion.add(dev)
    dev1 = Desarrollador(
        cedula = '159753',
        nombre_apellido = 'Rafael',
        fecha_ingreso = datetime.now(),
        area = Desarrollador.Areas.ANALISIS,
        estado = Desarrollador.Estados.ACTIVO,
        codigo_especialidad = 1
    )
    sesion.add(dev1)
    sesion.commit()
    sesion.close()

def consultas():
    sesion = Session()
    desarrolladores = sesion.query(Desarrollador).all()
    print(desarrolladores)
    desarrolladores_jr = sesion.query(Desarrollador).\
        filter(Desarrollador.codigo_especialidad == 1).all()
    print(desarrolladores_jr)
    cantidad_desarrolladores = sesion.query(Desarrollador).\
        count()
    print(cantidad_desarrolladores)
    rafael = sesion.get(Desarrollador, '159753')
    print(rafael)
    sesion.close()

if __name__ == '__main__':
    #agregar_especialidad()
    #agregar_desarrollador()
    consultas()