from models import * 
from db import Session
from  datetime import *


def Speciality():
    session = Session()
    speciality = Especialidad(codigo =123, nombre = 'Desarrollador jr', salario_base = 800, estado = Especialidad.Estados.ACTIVO)
    session.add(speciality)
    session.commit()


def Add_Proyect():
    session = Session()
    pro = Proyecto(codigo = 7887, nombre= 'Proyect X', fecha_inicio = datetime.now(), fecha_final = datetime.now(), estado= Proyecto.Estados.ACTIVO)
    session.add(pro)
    session.commit()

def main():
    Add_Proyect()
    #Speciality()
if __name__ == '__main__':
    main()



