# Cake decoration
varFrosting = input('Enter the cake frosting: ')
varFilling =  input('Enter the cake filling: ')

def cake_Decoration_Filling():
    def wrapper_Function(function):
        global varFilling
        var = function()
        print(var+' With Decoration of Filling: '+varFilling)
        return function
    return wrapper_Function

def cake_Decoration():
    def wrapper_Function(function):
        global varFrosting
        var = function()
        #varX = input('Enter the cake frosting: ')
        print(var+' With Decoration of: '+varFrosting)
        input('')
        return function
    return wrapper_Function

@cake_Decoration()
@cake_Decoration_Filling()
def biscuit():
    return 'Biscocho'
biscuit()


