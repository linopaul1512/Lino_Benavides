def validate_ByZero(function):
    def validation (num1,num2):
        if(num2==0):
            print('Error! Division by Zero')
        else:
            return function(num1,num2)
        return validation(num1,num2)
    

@validate_ByZero
def division():
    global num1
    global num2
    print(num1/num2)

#print(say_hi())