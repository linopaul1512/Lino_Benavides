"""
def decorator(funtion):
    def internal_Funtion():
        print('1-inside of the internal funtion')
        funtion()
    return internal_Funtion()


def other_Funtion(): #Function 3
    print('2-inside other funtion')



var = decorator(other_Funtion)

"""
def Add(x,y):
    return x+y

def Rest(x,y):
    return x-y

def decorator(function,x,y):
    result = function(x,y)
    return result


print (decorator(Add,7,8))
print (decorator(Rest,7,8))




