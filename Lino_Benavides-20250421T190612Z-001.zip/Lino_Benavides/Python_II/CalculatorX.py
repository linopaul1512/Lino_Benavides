from operations.Add import Add
from operations.Rest import Rest
from operations.Division import DivisionOperation

def main():
    print('Welcome to the program Calculators***\n')
    number1 = float(input ('Please enter tue number#1: '))
    number2 = float(input ('Please enter tue number#2: '))
    resp= 0
    while (resp!=5):
        print('****MENÚ****')
        print('Choice one option: \n')
        print ('1- Add two numbers')
        print ('2- Rest two numbers')
        print ('3- Multiply two numbers')
        print ('4- Division two numbers')
        print('5- Exit the Program')
        resp= int (input('Enter the optio:'))
        if (resp==1):
           # print('call Funtion add\n')
            Add(number1, number2)
            input('Enter for continue')
            
        elif (resp==2):
            #print('call Funtion Rest\n')
            Rest(number1, number2)
            input('Enter for continue')       
        elif (resp==3):
            print('call Funtion Multiply\n')
            input('Enter for continue')
        elif (resp==4):
            # print('call Funtion Division\n')
            DivisionOperation(number1, number2)
            input('Enter for continue')               

if __name__== '__main__':
    main()