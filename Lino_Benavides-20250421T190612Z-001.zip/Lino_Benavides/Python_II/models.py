from db import Base
from enum import Enum as Enumerador
from sqlalchemy import Column, Integer, String, Date, Enum, ForeignKey, Float
from sqlalchemy.orm import relationship

class Proyecto(Base):
    class Estados(Enumerador):
     ACTIVATED = 'A'
     INACTIVATED = 'I'

    __tablename__ = 'proyectos'

    codigo = Column(Integer, primary_key = True)
    nombre = Column(String)
    fecha_inicio = Column(Date)
    fecha_final = Column(Date)
    estado = Column(Enum(Estados))

    requisitos = relationship('Requisito', back_populates = 'proyecto')
    desarrolladores = relationship('Desarrollador', back_populates = 'proyecto')

class Requisito(Base):
    class Tipos(Enumerador):
        FUNCIONAL = 'F'
        NOFUNCIONAL = 'N'

    class Estados(Enumerador):
        PENDIENTE = 'P'
        ENDESARROLLO = 'D'
        FINALIZADO = 'F'
        ELIMINADO = 'I'

    __tablename__ = 'requisitos'

    codigo = Column(Integer, primary_key = True)
    nombre = Column(String)
    tipo = Column(Enum(Tipos))
    especificacion = Column(String)
    estado = Column(Enum(Estados))

    codigo_proyecto = Column(Integer, ForeignKey('proyectos.codigo'))
    proyecto = relationship('Proyecto', back_populates = 'requisitos')
    casos_de_uso = relationship('CasoDeUso', back_populates = 'requisito')

class CasoDeUso(Base):
    class Estados(Enumerador):
        PENDIENTE = 'P'
        ENDESARROLLO = 'D'
        FINALIZADO = 'F'
        ELIMINADO = 'I'

    __tablename__ = 'casos_de_uso'

    codigo = Column(Integer, primary_key = True)
    nombre = Column(String)
    actor = Column(String)
    especificacion = Column(String)
    estado = Column(Enum(Estados))

    codigo_requisito = Column(Integer, ForeignKey('requisitos.codigo'))
    requisito = relationship('Requisito', back_populates = 'casos_de_uso')

class Desarrollador(Base):
    class Areas(Enumerador):
        ANALISIS = 'A'
        DISEÑO = 'D'
        DESARROLLO = 'S'
        QA = 'Q'
        MANTENIMIENTO = 'M'

    class Estados(Enumerador):
        ACTIVO = 'A'
        ELIMINADO = 'I'

    __tablename__ = 'desarrolladores'

    cedula = Column(String, primary_key = True)
    nombre_apellido = Column(String)
    fecha_ingreso = Column(Date)
    area = Column(Enum(Areas))
    estado = Column(Enum(Estados))

    codigo_proyecto = Column(Integer, ForeignKey('proyectos.codigo'))
    proyecto = relationship('Proyecto', back_populates = 'desarrolladores')
    codigo_especialidad = Column(Integer, ForeignKey('especialidades.codigo'))
    especialidad = relationship('Especialidad', back_populates = 'desarrolladores')
    
    def __repr__(self):
        return f'{self.cedula}: {self.nombre_apellido}'

class Especialidad(Base):
    class Estados(Enumerador):
        ACTIVO = 'A'
        ELIMINADO = 'I'

    __tablename__ = 'especialidades'

    codigo = Column(Integer, primary_key = True)
    nombre = Column(String)
    salario_base = Column(Float)
    estado = Column(Enum(Estados))

    desarrolladores = relationship('Desarrollador', back_populates = 'especialidad')

    def __repr__(self):
        return f'{self.nombre} - ${self.salario_base}/hr\n'