from sqlalchemy import String, Date, Integer, Column
from db import Base

class Person(Base):
    __tablename__='person'
    id = Column(Integer, primary_key=True)
    name = Column(String)
    lastname = Column(String)
    datebirth = Column(Date)
    status = Column(String)

    def __repr__(self):
        return f'User: Id {self.id}; Name {self.name}; Lastname: {self.lastname}; Date Birth: {self.datebirth}; Status: {self.status}'


