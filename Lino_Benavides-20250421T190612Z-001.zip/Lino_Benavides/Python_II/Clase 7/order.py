from sqlalchemy import String, Date, Integer, Column, ForeignKey
from sqlalchemy.orm import relationship
from db import Base

class Order(Base):
    __tablename__='order'

    id = Column(Integer, primary_key=True)
    lastname = Column(String)

    client_id = Column(Integer, ForeignKey("client.id"))
    client = relationship('client', back_populates ='order')