from db import engine,Base
from person import Person
from client import Client
from order import Order

if __name__=='__main__':
    Base.metadata.create_all(engine)
        