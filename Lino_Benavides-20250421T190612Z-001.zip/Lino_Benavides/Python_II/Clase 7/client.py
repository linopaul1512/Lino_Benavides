from sqlalchemy import String, Date, Integer, Column, ForeignKey
from sqlalchemy.orm import relationship
from db import Base

class Client(Base):
    __tablename__='client'

    id = Column(Integer, primary_key=True)
    name = Column(String)
    lastname = Column(String)
    datebirth = Column(Date)
    status = Column(String) 

    order = relationship('order', back_populates = 'client') 