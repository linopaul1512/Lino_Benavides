import tkinter as tk
from tkinter import messagebox
from operations import ErrorSintasisProductos


class Products():
    def __init__(self) -> None:
        self.window = tk.Tk()
        self.window.title('Products')
        self.window.geometry('300x300')
        self.cod = tk.StringVar()
        self.description = tk.StringVar()
        self.price = tk.StringVar()
        self.quantity = tk.StringVar()
        self.expiditiondate = tk.StringVar()
        self.fabricationdate = tk.StringVar()


        #Labels


        self.labelCod = tk.Label(self.window, text="Code")
        self.labelCod.place(x=5, y=10)

        self.labelDescription = tk.Label(self.window, text="Description")
        self.labelDescription.place(x=5, y=40)

        self.labelPrice = tk.Label(self.window, text="Price")
        self.labelPrice.place(x=5, y=80)

        self.labelQuantity = tk.Label(self.window, text="Quantity")
        self.labelQuantity.place(x=5, y=120)

        self.labelExpirationDate = tk.Label(self.window, text="Expiration Date")
        self.labelExpirationDate.place(x=5, y=160)        

        self.labelFabricationDate = tk.Label(self.window, text="Fabrication Date")
        self.labelFabricationDate.place(x=5, y=200)

        self.entryCod = tk.Entry(self.window, width=20, textvariable=self.cod)
        self.entryCod.place(x=100,y=10)


        #Entrys


        self.entryDescription = tk.Entry(self.window, width=20, textvariable=self.description)
        self.entryDescription.place(x=100,y=40)  
        
        self.entryPrice = tk.Entry(self.window, width=20, textvariable=self.price)
        self.entryPrice.place(x=100,y=80)  

        self.entryQuantity = tk.Entry(self.window, width=20, textvariable=self.quantity)
        self.entryQuantity.place(x=100,y=120)  

        self.entryExpirationDate = tk.Entry(self.window, width=20, textvariable=self.expiditiondate)
        self.entryExpirationDate.place(x=100,y=160)  

        self.entryFabricationDate = tk.Entry(self.window, width=20, textvariable=self.fabricationdate)
        self.entryFabricationDate.place(x=100,y=200)  


        #Buttons


        self.ButtonAdd = tk.Button(self.window, text='Add', command=(self.ButtonAdd))
        self.ButtonAdd.place(x=5,y=240)   

        self.ButtonClean = tk.Button(self.window, text='Clean', command=(self.ButtonCleanX))
        self.ButtonClean.place(x=100,y=240) 



        self.window.mainloop()


    def ButtonClick(self,contenido):
        click =self.operation.get()+str(contenido)
        self.operation.set(click)

    def ButtonAdd(self):

        try:
           messagebox.INFO('Product Saved Successfully') 
        except SyntaxError as e:
            self.price
            messagebox.showerror('Syntax Erros!!!', str(e))
            print(e)

    def ButtonCleanX(self):
        self.cod.set("")
        self.description.set("")
        self.price.set("")
        self.quantity.set("")
        self.expiditiondate.set("")
        self.fabricationdate.set("")

def main():
    productsx = Products()
if __name__=='__main__':
    main()