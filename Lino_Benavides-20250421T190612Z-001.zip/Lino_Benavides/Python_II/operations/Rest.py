def Rest(n1,n2):
    print('The rest is: '+str(n1-n2))