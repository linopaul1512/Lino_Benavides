from tkinter import messagebox
def SyntaxError(e):
    messagebox.showerror('Errorthe Systax', e+'Error the Systax!!!')
    