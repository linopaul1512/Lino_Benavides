def Add(n1,n2):
    print('The sum is: '+str(n1+n2))