def DivisionOperation(n1,n2):
    
    try:
        result=n1/n2
        print('Result of division: '+result)
    except ZeroDivisionError as e:
        print('ERROR!!!!\n')
        print('The error is: '+str(e)+'\n')
    else:
        print('No hubo Error!!!\n')
    finally:
        print('END OD THE PROGRAM!!!\n')
        