import Trigonometric as t
def x():
    t.cos(5)

def y():
    t.sen(5)





"""
def Oper():
    print('*****************')
    print(str(t.acos(5))+'\n')
    print('************** \n')

Oper()

"""
