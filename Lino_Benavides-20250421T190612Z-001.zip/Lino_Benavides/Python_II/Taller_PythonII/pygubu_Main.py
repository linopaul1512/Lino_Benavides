#!/usr/bin/python3
import pathlib
import pygubu
from dbdeparment import Session
from models import Deparment
from tkinter import messagebox
from models import *

PROJECT_PATH = pathlib.Path(__file__).parent
PROJECT_UI = PROJECT_PATH / "deparment.ui"


class DeparmentApp:
    def __init__(self, master=None):
        self.builder = builder = pygubu.Builder()
        builder.add_resource_path(PROJECT_PATH)
        builder.add_from_file(PROJECT_UI)
        # Main widget
        self.mainwindow = builder.get_object("toplevel1", master)
        builder.connect_callbacks(self)


        self.cod = builder.get_object('entrycod')
        self.description = builder.get_object('entrydescription')       
        self.type = builder.get_object('entrytype')
        self.price = builder.get_object('entryprice')
        self.saleprice = builder.get_object('entrysaleprice')

        #tupla
        uivars = ('textVar_cod', 'textVar_description','textVar_type', 'textVar_price', 'textVar_saleprice')
        #le decimos constructor le decimos que trabaje con esas variables
        builder.import_variables(self, uivars)

    def run(self):
        self.mainwindow.mainloop()

    def function_pause(self):
        session = Session()
        var_cod = self.cod.get()

        deparment= session.query(Deparment).\
                  filter(Deparment.cod==var_cod).\
                  update({'status': 'ON_PAUSE'})
        session.commit()
        session.close()
        messagebox.showinfo( message='Leisurely department!!', title='On Pause')
        self.function_clean()

    def function_sold(self):
        session = Session()
        var_cod = self.cod.get()

        deparment= session.query(Deparment).\
                  filter(Deparment.cod==var_cod).\
                  update({'status': 'SOLD'})
        session.commit()
        session.close()
        messagebox.showinfo( message='Department sold!!', title='Sold')
        self.function_clean()

    def function_include(self):
       session = Session() #Permite establecer conexion con la base de datos

       if(self.type.get()=='Basic'):
            saleprice= int(self.price.get()) * 1.10
            self.textVar_saleprice.set(saleprice)
       elif(self.type.get()=='Duplex'):
            saleprice= int(self.price.get()) * 1.15
            self.textVar_saleprice.set(saleprice)
       else:
            saleprice= int(self.price.get()) * 1.30
            self.textVar_saleprice.set(saleprice)

    
       deparment = Deparment(cod = self.cod.get(),
                          description = self.description.get(),
                          type = self.type.get(),
                          price = float(self.price.get()), 
                          saleprice = saleprice, 
                          status = Deparment.States.Published)

       session.add(deparment)
       session.commit()
       session.close()
       messagebox.showinfo( message='Deparment save!!', title='Information')       



    def function_search(self):
        session = Session()
        var_cod = self.cod.get()

        
        deparmentx = session.get(Deparment, int(var_cod))
        self.textVar_description.set(deparmentx.description)
        self.textVar_type.set(deparmentx.type )
        self.textVar_price.set(deparmentx.price)
        self.textVar_saleprice.set(deparmentx.saleprice)
        messagebox.showinfo( message='Product found !!', title='Information')

    def function_modify(self):
        session = Session()
        var_cod = self.cod.get()

        deparment= session.query(Deparment).\
                  filter(Deparment.cod==var_cod).\
                  update({'description': self.description.get(),
                          'type': self.type.get(), 
                          'price': self.price.get(), 
                          'saleprice': self.saleprice.get()})
        session.commit()
        session.close()
        messagebox.showinfo( message='Deparment Modify!!', title='Modify')
        self.function_clean()

    def function_delete(self):
        session = Session()
        var_cod = self.cod.get()

        deparment= session.query(Deparment).\
                  filter(Deparment.cod==var_cod).\
                  update({'status': 'INACTIVATED'})
        session.commit()
        session.close()
        messagebox.showinfo( message='Deparment Delete!!', title='Delete')
        self.function_clean()

    def function_clean(self):
        self.textVar_cod.set('')
        self.textVar_description.set('')
        self.textVar_type.set('')
        self.textVar_price.set('')
        self.textVar_saleprice.set('')


if __name__ == "__main__":
    app = DeparmentApp()
    app.run()
