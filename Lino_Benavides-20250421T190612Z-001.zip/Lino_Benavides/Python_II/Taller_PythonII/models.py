from dbdeparment import Base
from enum import Enum as Enumerador
from sqlalchemy import Column, Integer, String, Date, Enum, ForeignKey, Float
from sqlalchemy.orm import relationship



class Deparment(Base):
    class States(Enumerador):
     Published = 'P' #seria como activo
     INACTIVATED = 'I'
     SOLD = 'S'
     ON_PAUSE = 'O'

    __tablename__ = 'deparment'

    cod = Column(Integer, primary_key = True)
    description = Column(String)
    type = Column(String)
    price = Column(Float)
    saleprice = Column(Float)
    status = Column(Enum(States))
