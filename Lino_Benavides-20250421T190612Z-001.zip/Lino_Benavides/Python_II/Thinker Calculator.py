# Tkinter Calculator {}{}}
import tkinter as tk
from tkinter import messagebox
#from operations import Trigonometric
from operations import ErrorSintasis

class AplicationX():
    def __init__(self) -> None:
        self.window = tk.Tk()
        self.window.title('Calculator X')
        self.window.geometry('300x300')
        self.operation = tk.StringVar()

        self.entryOperation = tk.Entry(self.window, state='disable', width=20, textvariable=self.operation)
        self.entryOperation.place(x=80,y=10)

        self.ButtonNumber7 = tk.Button(self.window, text='7',command=lambda:(self.ButtonClick(7)))
        self.ButtonNumber7.place(x=90,y=40)
        self.ButtonNumber8 = tk.Button(self.window, text='8',command=lambda:(self.ButtonClick(8)))
        self.ButtonNumber8.place(x=110,y=40)
        self.ButtonNumber9 = tk.Button(self.window, text='9', command=lambda:(self.ButtonClick(9)))
        self.ButtonNumber9.place(x=130,y=40)

        self.ButtonAdd = tk.Button(self.window, text='+', command=lambda:(self.ButtonClick('+')))
        self.ButtonAdd.place(x=170,y=40)
        self.ButtonMultiply = tk.Button(self.window, text='*', command=lambda:(self.ButtonClick('*')))
        self.ButtonMultiply.place(x=170,y=70)
        self.ButtonRest = tk.Button(self.window, text='-', command=lambda:(self.ButtonClick('-')))
        self.ButtonRest.place(x=190,y=40)
        self.ButtonDivision = tk.Button(self.window, text=' /', command=lambda:(self.ButtonClick(' /')))
        self.ButtonDivision.place(x=190,y=70)


        self.ButtonCoseno = tk.Button(self.window, text='Coseno', command=lambda:(self.ButtonClick(' Coseno')))
        self.ButtonCoseno.place(x=190,y=200)

        self.ButtonSeno = tk.Button(self.window, text='Seno', command=lambda:(self.ButtonClick('Seno')))
        self.ButtonSeno.place(x=190,y=230)
        
        self.ButtonCalc = tk.Button(self.window, text='=', command=self.ButtonResult)
        self.ButtonCalc.place(x=180 , y= 100)

        self.ButtonClean = tk.Button(self.window, text='Clean', command=self.ButtonClean)
        self.ButtonClean.place(x=180 , y= 130)

        self.ButtonNumber4 = tk.Button(self.window, text='4',command=lambda:(self.ButtonClick(4)))
        self.ButtonNumber4.place(x=90,y=70)
        self.ButtonNumber5 = tk.Button(self.window,text='5',command=lambda:(self.ButtonClick(5)))
        self.ButtonNumber5.place(x=110,y=70)
        self.ButtonNumber6 = tk.Button(self.window, text='6',command=lambda:(self.ButtonClick(6)))
        self.ButtonNumber6.place(x=130,y=70)

        self.ButtonNumber1 = tk.Button(self.window, text='1',command=lambda:(self.ButtonClick(1)))
        self.ButtonNumber1.place(x=90,y=100)
        self.ButtonNumber2 = tk.Button(self.window, text='2',command=lambda:(self.ButtonClick(2)))
        self.ButtonNumber2.place(x=110,y=100)
        self.ButtonNumber3 = tk.Button(self.window, text='3',command=lambda:(self.ButtonClick(3)))
        self.ButtonNumber3.place(x=130,y=100)

        self.ButtonNumber0 = tk.Button(self.window, text='0',command=lambda:(self.ButtonClick(0)))
        self.ButtonNumber0.place(x=110,y=130)



        self.window.mainloop()

 
    def ButtonClick(self, num):
        click =self.operation.get()+str(num)
        self.operation.set(click)

    def ButtonResult(self):
        try:
            result = eval(self.operation.get())
            self.operation.set(str(result))

        
        except ZeroDivisionError as e:
            #self.operation.set(str(result))
            messagebox.showerror('Zero Division Error!!!',str(e))
            print(e)
             

        except SyntaxError as e:
            messagebox.showerror('Syntax Erros!!!', str(e))
            print(e)
            
            
        #else:
         #   self.operation.set("")



    def ButtonClean(self):
        self.operation.set("")


def main():
    calculatorX = AplicationX()
if __name__=='__main__':
    main()


