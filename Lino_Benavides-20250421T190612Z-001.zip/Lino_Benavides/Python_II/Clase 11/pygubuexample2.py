#!/usr/bin/python3
import pathlib
import pygubu
from tkinter import messagebox
PROJECT_PATH = pathlib.Path(__file__).parent
PROJECT_UI = PROJECT_PATH / "Proyecto ejemplo 2.py"


class ProyectoEjemplo2App:
    def __init__(self, master=None):
        self.builder = builder = pygubu.Builder()
        builder.add_resource_path(PROJECT_PATH)
        builder.add_from_file(PROJECT_UI)
        # Main widget
        self.mainwindow = builder.get_object("toplevel1", master)
        builder.connect_callbacks(self)

        #Coding
        self.entry_answer = builder.get_object('entry_answer')


    def run(self):
        self.mainwindow.mainloop()

    def function_clicked(self):
        if(self.entry_answer.get()=='python'):
            messagebox.showinfo('info Answer', 'Clickec!!')
        else:
            messagebox.showerror('Error Entry Answer', 'the answer is incorrect: :( )')
            


if __name__ == "__main__":
    app = ProyectoEjemplo2App()
    app.run()
