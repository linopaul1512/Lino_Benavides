#!/usr/bin/python3
import pathlib
import pygubu
from dbproduct2 import Session
from tkinter import messagebox
from models import *

PROJECT_PATH = pathlib.Path(__file__).parent
PROJECT_UI = PROJECT_PATH / "product.ui"


class ProductApp:
    def __init__(self, master=None):
        self.builder = builder = pygubu.Builder()
        builder.add_resource_path(PROJECT_PATH)
        builder.add_from_file(PROJECT_UI)
        # Main widget
        self.mainwindow = builder.get_object("toplevel1", master)
        builder.connect_callbacks(self)


       
        self.id = builder.get_object('entryid')
        self.description = builder.get_object('entrydescription')
        self.price = builder.get_object('entryprice')
        self.stock = builder.get_object('entrystock')
        #tupla
        uivars = ('textVar_id', 'textVar_description','textVar_price', 'entryVar_stock')
        #le decimos constructor le decimos que trabaje con esas variables
        builder.import_variables(self, uivars)



    def run(self):
        self.mainwindow.mainloop()

    def function_Add(self):
        session = Session() #Permite establecer conexion con la base de datos
        product = Product(id = self.id.get(),
                          description = self.description.get(), 
                          price = float(self.price.get()), 
                          stock = int (self.stock.get()), 
                          status = Product.States.ACTIVATED)

        session.add(product)
        session.commit()
        session.close()
        messagebox.showinfo( message='Product save!!', title='Information')

    
    def function_Clean(self):
        self.textVar_id.set('')
        self.textVar_description.set('')
        self.textVar_price.set('')
        self.entryVar_stock.set('')
        

    def function_Search(self):
        session = Session()
        var_id = self.id.get()

        productx = session.get(Product, int(var_id))
        self.textVar_description.set(productx.description)
        self.textVar_price.set(productx.price )
        self.entryVar_stock.set(productx.stock)
        messagebox.showinfo( message='Product found !!', title='Information')

    def function_Delete(self):
        session = Session()
        var_id = self.id.get()

        productx= session.query(Product).\
                  filter(Product.id==var_id).\
                  update({'status': 'INACTIVATED'})
        session.commit()
        session.close()
        messagebox.showinfo( message='Product delete!!', title='Delete')
        self.function_Clean()

    """def function_Delete(self):
        session = Session()
        var_id = self.id.get()
        productx = session.get(Product, int(var_id))
        session.delete(productx)
        session.commit()
        session.close()
        messagebox.showinfo( message='Product delete!!', title='Delete')
        self.function_Clean()"""

    def function_modify(self):
        session = Session()
        var_id = self.id.get()

        productx= session.query(Product).\
                  filter(Product.id==var_id).\
                  update(productx)
        session.commit()
        session.close()
        messagebox.showinfo( message='Product Modify!!', title='Modify')
        self.function_Clean()

if __name__ == "__main__":
    app = ProductApp()
    app.run() 

