from dbproduct2 import Base
from enum import Enum as Enumerador
from sqlalchemy import Column, Integer, String, Date, Enum, ForeignKey, Float, CHAR
from sqlalchemy.orm import relationship


class Product(Base):
    class States(Enumerador):
     INACTIVATED = 'P'
     ACTIVATED = 'A'

    __tablename__ = 'products'

    id = Column(Integer, primary_key = True)
    description = Column(String)
    price = Column(Float)
    stock = Column(Integer)
    status = Column(Enum(States))

    