from sqlalchemy import String, Date, Integer, Column, Double, ForeignKey
from database import Base
from sqlalchemy.orm import relationship

class Especialidad(Base):
    __tablename__='especialidad'
    code = Column(Integer, primary_key=True)
    name = Column(String)
    basesalary = Column(Double)
    status = Column(String)

    def __repr__(self):
        return f'Especiality: Code  {self.code}; Name {self.name};Base Salary: {self.basesalary}; Status: {self.status}'
