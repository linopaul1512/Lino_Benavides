from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base

engine = create_engine('sqlite:///database.sqliteProyect')
engine.connect()

Base = declarative_base()