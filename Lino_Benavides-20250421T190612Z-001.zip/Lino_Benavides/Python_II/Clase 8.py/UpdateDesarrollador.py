from database import engine,Base
from desarrollador import Desarrollador
from proyect import Proyect
from especialidad import Especialidad
from requisito import Requisito
from casosdeUso import CasodeUso



if __name__=='__main__':
    Base.metadata.create_all(engine)