from sqlalchemy import String, Date, Integer, Column, ForeignKey
from database import Base
from sqlalchemy.orm import relationship

class Desarrollador(Base):
    __tablename__='desarrollador'
    id = Column(Integer, primary_key=True)
    name = Column(String)
    lastname = Column(String)
    Dateofadmission = Column(Date)
    Area = Column(String)
    Projectcode = Column(String)
    Specialtycode = Column(String)


    status = Column(String)

    def __repr__(self):
        return f'User: Id {self.id}; Name {self.name}; Lastname: {self.lastname}; Date of Admission: {self.Dateofadmission}; Área: {self.Area}; Project Code: {self.Projectcode}; Speciality Code{self.Specialtycode}; Status: {self.status}'
