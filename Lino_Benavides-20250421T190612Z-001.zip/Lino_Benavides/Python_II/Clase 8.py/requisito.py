from sqlalchemy import String, Date, Integer, Column, ForeignKey
from database import Base
from sqlalchemy.orm import relationship

class Requisito(Base):
    __tablename__='requisito'
    code = Column(Integer, primary_key=True)
    name = Column(String)
    type = Column(String)
    specification = Column(String)
    projectcode = Column(String)
    status = Column(String)


    def __repr__(self):
        return f'Requisito: code {self.code}; Name {self.name}; Type: {self.type}; Specification: {self.specification}; Project Code: {self.projectcode}; Status: {self.status}'