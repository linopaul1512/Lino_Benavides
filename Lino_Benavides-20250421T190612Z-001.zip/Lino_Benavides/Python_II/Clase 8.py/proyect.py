from sqlalchemy import String, Date, Integer, Column, ForeignKey
from database import Base
from sqlalchemy.orm import relationship

class Proyect(Base):
    __tablename__='proyect'
    code = Column(Integer, primary_key=True)
    name = Column(String)
    startdate = Column(Date)
    enddate = Column(Date)
    status = Column(String)

    def __repr__(self):
        return f'User: code {self.code}; Name {self.name}; Star Date: {self.startdate}; Área: {self.enddate}; Status: {self.status}'
