#!/usr/bin/python3
import tkinter as tk
import pathlib
from tkinter import messagebox
import pygubu
from DatabaseJSS import Session
from  JSS_Model import Raw_Material as raw_material
from  JSS_Model import Production_Order as order
from  JSS_Model import Material_Order as material_order
PROJECT_PATH = pathlib.Path(__file__).parent
PROJECT_UI = PROJECT_PATH / "Material_Order.ui"


class Material_Order:
    def __init__(self, master=None):
        self.builder = builder = pygubu.Builder()
        builder.add_resource_path(PROJECT_PATH)
        builder.add_from_file(PROJECT_UI)
        # Main widget
        self.mainwindow = builder.get_object("toplevel1", master)
        builder.connect_callbacks(self)
        self.Code_order = builder.get_object("entry_Code")
        self.Description = builder.get_object("entry_Des")
        self.Code_Material = builder.get_object("entry_Cod_M")
        self.Quantity = builder.get_object("entry_Q")
        self.Unique_code = builder.get_object("entry_C")
        self.Description.config(state = "disabled")

        self.tree = builder.get_object("teeview_date")
        self.column = ("column_Des","colum_unit","column_Q") 


        uivars = ('textvar_Cod','textvar_Des','textvar_CodeM','textvar_Q','textvar_Code')
        builder.import_variables(self,uivars)

    def run(self):
        self.mainwindow.mainloop()


        

    def Function_SearchO(self):
        session = Session()
        var_cod = self.Code_order.get()
        oderr = session.get(order,int(var_cod))
        messagebox.showinfo("Found","code found")         
        self.Code_order.config(state = "disabled")
        self.Description.config(state = "disabled")
        self.textvar_Des.set(oderr.Product)



    def Function_SearchM(self):
        session = Session()
        var_cod = self.Code_Material.get()
        raw = session.get(raw_material,str(var_cod))
        messagebox.showinfo("Found","code found")     
        self.Code_Material.config(state = "disabled")




    def Function_Add(self):

        

        var_cod = self.Code_Material.get()
        session = Session()
        raw = session.get(raw_material,str(var_cod))
        total = raw.Unit_cost * int(self.textvar_Q.get())
        if(raw != None):
            messagebox.showinfo('Found','Infomation Found')

            self.Quantity.config(state = "disabled")
            self.tree.insert("",tk.END,values=(raw.Description ,raw.Unit_cost,self.textvar_Q.get(),str(total)))
            


        else:
            messagebox.showinfo('Found','Infomation not Found')

    
    
    def Function_Clean(self):
        self.textvar_Cod.set('')
        self.textvar_Des.set('')
        self.textvar_CodeM.set('')
        self.textvar_Q.set('')
        self.textvar_Code.set('')
        self.Code_order.config(state = 'normal')
        self.Code_Material.config(state = 'normal')



if __name__ == "__main__":
    app = Material_Order()
    app.run()

