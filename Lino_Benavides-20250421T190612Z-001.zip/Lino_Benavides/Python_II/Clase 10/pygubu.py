#!/usr/bin/python3
import tkinter as tk
import tkinter.ttk as ttk


class App:
    def __init__(self, master=None):
        # build ui
        toplevel1 = tk.Tk() if master is None else tk.Toplevel(master)
        toplevel1.configure(height=500, width=500)
        frame2 = ttk.Frame(toplevel1)
        frame2.configure(height=300, width=300)
        self.label4 = ttk.Label(frame2)
        self.label4.configure(text='Welcome to jungle:')
        self.label4.grid(column=0, row=0, sticky="w")
        entry1 = ttk.Entry(frame2)
        entry1.grid(column=1, row=0, sticky="sew")
        self.button_welcome = ttk.Button(frame2)
        self.button_welcome.configure(text='Enter')
        self.button_welcome.grid(column=0, row=3)
        frame2.pack(side="top")

        # Main widget
        self.mainwindow = toplevel1

    def run(self):
        self.mainwindow.mainloop()


if __name__ == "__main__":
    app = App()
    app.run()
