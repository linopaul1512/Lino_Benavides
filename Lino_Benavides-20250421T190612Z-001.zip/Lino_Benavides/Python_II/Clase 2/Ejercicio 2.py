class Farm:
    def __init__(self, code,acquisitionDate, constructionDate,size)->None:
        self.code = code
        self.acquisitionDate = acquisitionDate
        self.constructionDate = constructionDate
        self.size= size
    def comparizonSize(self,sizeX):
        if (self.size > sizeX):
            print(f'the mayor size is: {self.size}\n')
            print(f'the menor size is: {sizeX}')
        else:
            print(f'the mayor size is: {sizeX}\n')
            print(f'the menor size is: {self.size}')

    def __lt__(self,sixewX):
        return self.size  < sixewX
    def __gt__(self,sixewX):
        return self.size >  sixewX   
    def __str__(self):
        return f'Code:{self.code}\n Acquisition Date: {self.acquisitionDate} \nConstruction Date{self.constructionDate} \n Size: {self.size}'    
    

def main():
    print('*********************************************')
    objFarmOne = Farm('F-01','12/01/2023','12/01/2000',20)
    objFarmTwo = Farm('F-02','12/01/2T020','12/01/2015',18)
    print(objFarmOne)
    print(objFarmTwo)
    print(objFarmOne  > objFarmTwo )
    print(objFarmOne <  objFarmTwo)

    """
    print('***End of the Program DetoditoX*****************')
    input('Press enter for exit!!!!')
    exit()
    """
if ( __name__ == '__main__'):
    main()

    