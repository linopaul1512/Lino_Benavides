class Person:
    def __init__(self, name, lastname) -> None:   
        self.name = name
        self.latsname = lastname
class in_Charge:
    def __init__(self, code, deparment) -> None:
        self.code= code
        self.deparment = deparment
class Student(Person): 
    def __init__(self, name, lastname, faculity, code,deparment) -> None:
        super().__init__(name, lastname) #Herencia
        self.faculity  = faculity
        self.code = code
        self.deparment = deparment
    def Show_Data(self):
        print('*************************************')
        print('The name of the student is: '+ self.name+ '\n')
        print('Your lastaneme is: '+ self.latsname+ '\n')
        print('Yor Faculity is: '+ self.faculity+ '\n')
        print('The work of the student is: '+ self.code + '\n')
        print('The Deparment of the student is: ' f+"{self.deparment}")
        input('Enter for Exit')

def main():
StudentX = Student('Siberia', 'Vilchez', 'Ingenieria', 'c13', 'System')
StudentX.Show_Data()

if (__name__=='__main__'):
    main()





