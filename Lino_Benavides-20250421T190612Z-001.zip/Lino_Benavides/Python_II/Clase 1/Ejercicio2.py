import tkinter as tk
from tkinter import ttk

class Calculator:
    def __init__(self)-> None:
        self.ventana = tk.Tk()
        self.ventana.title("Ejercicio 1")
        self.ventana.geometry("500x500+500+150")
        #self.ventana.config(bg="#A1F508", cursor="gumby")


        self.label = tk.Label(self.ventana, text="Ingrese el primer número")
        self.label.place(x=10, y=80)

        self.entrada_text_limpiar= tk.StringVar()

        self.entrada_text = tk.Entry(
            self.ventana,
            width = 30,
            font= ("Arial,18"), 
            textvariable= self.entrada_text_limpiar
        )

        self.entrada_text.place(x=10, y=100)
        
        #Para ingresar el segundo número
        self.entrada_text2_limpiar= tk.StringVar()

        self.label = tk.Label(self.ventana, text="Ingrese el segundo número numero")
        self.label.place(x=10, y=140)

        self.entrada_text2 = tk.Entry(
            self.ventana,
            width = 30,
            font= ("Arial,18"),
            textvariable= self.entrada_text2_limpiar
        )

        self.entrada_text2.place(x=10, y=170)

        

        self.button_sumar = tk.Button(
            self.ventana,
            text= "+", 
            command= self.Sumar
        )
        
        self.button_sumar.place(x=20, y =260)

        
        self.button_restar = tk.Button(
            self.ventana,
            text= "-", 
            command= self.Restar
        )
        
        self.button_restar.place(x=40, y =260)

        
        self.button_multipicar = tk.Button(
            self.ventana,
            text= "x", 
            command= self.Multiplicar
        )
        
        self.button_multipicar.place(x=60, y =260)

        
        self.buton_dividir = tk.Button(
            self.ventana,
            text= "÷", 
            command= self.Dividir
        )
        
        self.buton_dividir.place(x=80, y =260)

        self.button_clear = tk.Button(
            self.ventana,
            text= "Clear", 
            command= self.Clear
        )
        self.button_clear.place(x=100, y =260)


        self.labelresultado = tk.Label(self.ventana, text="Resultado")
        self.labelresultado.place(x=10, y=300)

        

        self.ventana.mainloop()

    def Sumar(self):
        resultado = float(self.entrada_text.get()) + float(self.entrada_text2.get()) 
        self.labelresultado.config(text=resultado)

        
    def Restar(self):
       resultado = float(self.entrada_text.get()) - float(self.entrada_text2.get()) 
       self.labelresultado.config(text=resultado)

    def Multiplicar(self):
        resultado = float(self.entrada_text.get())  * float(self.entrada_text2.get()) 
        self.labelresultado.config(text=resultado)

    def Dividir(self):
       resultado = float(self.entrada_text.get()) / float(self.entrada_text2.get()) 
       self.labelresultado.config(text=resultado)


    def Clear(self):
       self.entrada_text_limpiar.set('')
       self.entrada_text2_limpiar.set('')
      


def main():
    Calculator()

if __name__ == "__main__":
    main()        