"""x=15
def chinchunflay():
    global x
    x=20
    print('Printer value x on Chinchunflay function: '+str(x)+'\n')
    input("Please enter for continue")
chinchunflay()
print('Value of var X: '+str(x))


number1 = int(input('Please enter the first number:\n'))
number2 = int(input('Please enter the second number:\n'))
result = number1+number2
print('The result is: '+str(result))



print('***Welcome to The Program X***\n')
numberQuantity = int(input('Please enter the number of numbers to be processed:\n'))
acum =0 
for x in range(numberQuantity):
    numberX = input('Enter the numbrer #'+str(x+1)+': ')
    acum+=int(numberX)
    print('So far it has been: '+str(acum)+'\n')
print('***End Program X***')

"""
class Person():
        def __init__(self, name, age) -> None:
            self.name = name
            self.age = age
        def ShowData(self):
            print('***This is the data of the person***: \n')
            print('The name is:' + self.name)
            print('The age is:' + self.age)


print('Welcme to the program X')
nameX = input('Enter the name of person: ')
print('')
ageX = input('Enter the age of person: ')
print('')
personX = Person(nameX, ageX)
personX.ShowData()


    